"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/layout/header';
import { ProductGrid } from '@/components/inventory/product-grid';
import { TotalGrid } from '@/components/inventory/total-grid';
import { StatusSelector } from '@/components/status/status-selector';
import { AdminControls } from '@/components/admin/admin-controls';
import { PRODUCTS, initialShowStatuses } from '@/lib/data';
import { User, Stock, ShowStatus, Product } from '@/lib/types';
import { getStoredStock, setStoredStock, getStoredStatuses, setStoredStatuses, getStoredProducts, setStoredProducts } from '@/lib/storage';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [selectedShow, setSelectedShow] = useState<number | null>(null);
  const [showStatuses, setShowStatuses] = useState<ShowStatus[]>(initialShowStatuses);
  const [stock, setStock] = useState<Stock[]>([]);
  const [products, setProducts] = useState<Product[]>(PRODUCTS);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      router.push('/');
      return;
    }

    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== 'admin') {
      router.push('/');
      return;
    }

    setUser(parsedUser);
    
    // Load stored data
    const storedStock = getStoredStock();
    const storedStatuses = getStoredStatuses();
    const storedProducts = getStoredProducts();
    
    if (storedStock.length) setStock(storedStock);
    if (storedStatuses.length) setShowStatuses(storedStatuses);
    if (storedProducts.length) setProducts(storedProducts);
  }, [router]);

  const handleResetAllQuantities = () => {
    setStock([]);
    setStoredStock([]);
  };

  const handleResetAllStatuses = () => {
    const resetStatuses = showStatuses.map(status => ({
      ...status,
      status: 'Incomplete' as const,
      lastUpdated: new Date().toISOString()
    }));
    setShowStatuses(resetStatuses);
    setStoredStatuses(resetStatuses);
  };

  const handleAddProduct = (newProduct: Omit<Product, 'id'>) => {
    const id = `c${newProduct.category.slice(-1)}_${products.length + 1}`;
    const product: Product = { ...newProduct, id };
    const updatedProducts = [...products, product];
    setProducts(updatedProducts);
    setStoredProducts(updatedProducts);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
          <AdminControls
            onResetAllQuantities={handleResetAllQuantities}
            onResetAllStatuses={handleResetAllStatuses}
            onAddProduct={handleAddProduct}
          />
        </div>
        
        <div className="bg-white rounded-lg shadow mb-8">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Show</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {showStatuses.map((status) => (
                <TableRow 
                  key={status.showId}
                  className="cursor-pointer hover:bg-gray-50"
                  onClick={() => setSelectedShow(status.showId)}
                >
                  <TableCell>Show {status.showId}</TableCell>
                  <TableCell>
                    <StatusSelector
                      status={status.status}
                      onChange={() => {}}
                      disabled
                    />
                  </TableCell>
                  <TableCell>
                    {new Date(status.lastUpdated).toLocaleString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        <Tabs defaultValue="totals" className="space-y-4">
          <TabsList>
            <TabsTrigger value="totals">Show-T (Totals)</TabsTrigger>
            {selectedShow && (
              <TabsTrigger value="show">Show {selectedShow}</TabsTrigger>
            )}
          </TabsList>
          
          <TabsContent value="totals">
            <div>
              <h3 className="text-xl font-semibold mb-4">Total Quantities (Show-T)</h3>
              <TotalGrid
                products={products}
                stock={stock}
              />
            </div>
          </TabsContent>
          
          {selectedShow && (
            <TabsContent value="show">
              <div>
                <h3 className="text-xl font-semibold mb-4">Show {selectedShow} Inventory</h3>
                <ProductGrid
                  products={products}
                  stock={stock}
                  showId={selectedShow}
                  onUpdateStock={() => {}}
                  readOnly
                />
              </div>
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  );
}