"use client";

import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { Product } from '@/lib/types';

interface AdminControlsProps {
  onResetAllQuantities: () => void;
  onResetAllStatuses: () => void;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
}

export function AdminControls({
  onResetAllQuantities,
  onResetAllStatuses,
  onAddProduct,
}: AdminControlsProps) {
  const [newProduct, setNewProduct] = useState({ name: '', category: 'Column1' });

  const handleAddProduct = () => {
    if (newProduct.name.trim()) {
      onAddProduct(newProduct);
      setNewProduct({ name: '', category: 'Column1' });
    }
  };

  return (
    <div className="flex gap-4 mb-6">
      <Button 
        variant="destructive" 
        onClick={onResetAllQuantities}
      >
        Reset All Quantities
      </Button>
      
      <Button 
        variant="destructive" 
        onClick={onResetAllStatuses}
      >
        Reset All Statuses
      </Button>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline">Add New Product</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Input
                placeholder="Product Name"
                value={newProduct.name}
                onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <select
                className="w-full border rounded p-2"
                value={newProduct.category}
                onChange={(e) => setNewProduct(prev => ({ ...prev, category: e.target.value as any }))}
              >
                <option value="Column1">Column 1</option>
                <option value="Column2">Column 2</option>
                <option value="Column3">Column 3</option>
                <option value="Column4">Column 4</option>
                <option value="Column5">Column 5</option>
              </select>
            </div>
            <Button onClick={handleAddProduct}>Add Product</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}