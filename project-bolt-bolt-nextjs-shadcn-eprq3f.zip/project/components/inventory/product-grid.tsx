"use client";

import { Product, Stock } from '@/lib/types';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ProductGridProps {
  products: Product[];
  stock: Stock[];
  showId: number;
  onUpdateStock: (productId: string, quantity: number) => void;
  readOnly?: boolean;
}

export function ProductGrid({
  products,
  stock,
  showId,
  onUpdateStock,
  readOnly = false,
}: ProductGridProps) {
  const categories = ['Column1', 'Column2', 'Column3', 'Column4', 'Column5'];
  const categoryNames = {
    Column1: 'Column 1',
    Column2: 'Column 2',
    Column3: 'Column 3',
    Column4: 'Column 4',
    Column5: 'Column 5'
  };
  
  const getStockQuantity = (productId: string) => {
    const stockItem = stock.find(s => s.productId === productId && s.showId === showId);
    return stockItem?.quantity || 0;
  };

  return (
    <div className="space-y-6">
      {categories.map(category => {
        const categoryProducts = products.filter(p => p.category === category);
        if (categoryProducts.length === 0) return null;

        return (
          <div key={category} className="bg-white rounded-lg shadow">
            <div className="p-4 border-b">
              <h3 className="text-lg font-semibold">{categoryNames[category]}</h3>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Quantity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categoryProducts.map(product => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>
                      {readOnly ? (
                        <span>{getStockQuantity(product.id)}</span>
                      ) : (
                        <Input
                          type="number"
                          min="0"
                          value={getStockQuantity(product.id)}
                          onChange={(e) => onUpdateStock(product.id, parseInt(e.target.value) || 0)}
                          className="w-24"
                        />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        );
      })}
    </div>
  );
}