"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface StatusSelectorProps {
  status: 'Complete' | 'Incomplete';
  onChange: (status: 'Complete' | 'Incomplete') => void;
  disabled?: boolean;
}

export function StatusSelector({ status, onChange, disabled = false }: StatusSelectorProps) {
  return (
    <Select value={status} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder="Select status" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="Complete">Complete</SelectItem>
        <SelectItem value="Incomplete">Incomplete</SelectItem>
      </SelectContent>
    </Select>
  );
}